# PLATFORM_FIELDS · 评估流动性缺口

| 字段 | 内容 | 状态 |
|---|---|---|
| 任务名称 | 08 流动性缺口（对象＋版本＋动作） | 待定稿 |
| 任务类型 | TODO（按交付物形态填） | 待定稿 |
| L1/L2 行业 | 金融 / TODO | 待定稿 |
| L1/L2 职业 | TODO | 待定稿 |
| 三级 Skill | **评估流动性缺口** | 平台 Task ID `7705055005065203475` |
| 题目-文字 | 见 `01_PUBLIC_DOUBAO/PROMPT.template.md` | 待填占位符 |
| 题目-附件 | 见 `INPUT_CONTRACT.md` | 待真实材料 |
| 考点 | 见 `PLATFORM_EXPERT_RUBRIC.template.csv` | 待冻结 |
| 作答思路 | 见 `IDEAL_STEPS.template.md` | 待填 |
| 标准答案 | 见 `GOLDEN_RESPONSE.template.md` | **待独立计算** |
