# 金融八题 · 总包（SCAFFOLD）

- 题目数：8；每包 23 个文件
- 全部为脚手架：无业务数据、无标准答案、未跑豆测
- 难度闸门：Judge ≤50 且 单轮步数 ≥50（时长只评级）
- 理论结算：8 × 1,500 = 12,000 元（按全部质检合格计，非收入保证）

## 包清单

- `packages/FIN01_ALT_DATA.zip`
- `packages/FIN02_PRICE_VOLUME.zip`
- `packages/FIN03_ETF_ARB.zip`
- `packages/FIN04_PORT_ATTR.zip`
- `packages/FIN05_FX_SHOCK.zip`
- `packages/FIN06_CREDIT_MIGRATION.zip`
- `packages/FIN07_STRESS.zip`
- `packages/FIN08_LIQUIDITY_GAP.zip`